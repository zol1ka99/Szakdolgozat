$(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 100) {
        $('#mygotopbutton').fadeIn();
    } else {
        $('#mygotopbutton').fadeOut();
    }
});
$(document).ready(function() {
    $("#mygotopbutton").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});