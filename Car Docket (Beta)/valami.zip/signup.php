<?php
require "header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
            <h1>Regisztráció</h1>
            <?php
            if (isset($_GET['error'])) 
            {
                if ($_GET['error'] == "emptyfields") 
                {
                    echo '<p class"signuperror">Töltsön ki minden mezőt!</p>';
                }
                else if ($_GET['error'] == "invalidmailuid")
                {
                    echo '<p class"signuperror">Helytelen felhasználó és email cím!</p>';
                }
                else if ($_GET['error'] == "invaliduid")
                {
                    echo '<p class"signuperror">Helytelen felhasználónév!</p>';
                }
                else if ($_GET['error'] == "invalidmail")
                {
                    echo '<p class"signuperror">Érvénytelen email cím!</p>';
                }
                else if ($_GET['error'] == "passwordcheck")
                {
                    echo '<p class"signuperror">Nem egyeznek a jelszavak!</p>';
                }
                else if ($_GET['error'] == "usertaken")
                {
                    echo '<p class"signuperror">Felhasználónév foglalt</p>';
                }
            }
            else if ($_GET['signup'] == "success")
            {
                echo '<p class="signupsuccess">Signup successful!</p>';
            }
            ?>
            <form class="form-signup" action="includes/signup.inc.php" method="post">
                <input type="text" name="uid" placeholder="Felhasználónév">
                <input type="text" name="mail" placeholder="Email cím">
                <input type="password" name="pwd" placeholder="Jelszó">
                <input type="password" name="pwd-repeat" placeholder="Jelszó újra">
                <button type="submit" name="signup-submit">Regisztráció</button>
            </form>
        </section>
    </div>
</main>

<?php
require "footer.php";
?>