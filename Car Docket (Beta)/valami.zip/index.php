<?php
require "header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
            <?php
            if (isset($_SESSION['userid'])) 
            {
                echo '<p class="login-status">Őn belépett!</p>';
            }
            else
            {
                echo '<p class="login-status">Ön kilépett!</p>';
            }
            ?>
            <p class="login-status">Ki vagy jelentkezve!</p>
            <p class="login-status">Be vagy jelentkezve!</p>
        </section>
    </div>
</main>

<?php
require "footer.php";
?>